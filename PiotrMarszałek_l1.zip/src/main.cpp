#include <iostream>
#include "../include/PixelBuffer.h"
#include "../include/ImageWriter.h"

int main() {
    std::cout << "Hello, World!" << std::endl;

    // color ARGB
    PixelBuffer* pixelBuffer = new PixelBuffer(0xff0000ff ,256,256);
    ImageWriter* imageWriter = new ImageWriter();
    imageWriter->saveToFile(pixelBuffer, "test.tga");
}
