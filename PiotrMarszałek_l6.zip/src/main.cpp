#include <iostream>
#include "../include/PixelBuffer.h"
#include "../include/ImageWriter.h"
#include "../include/mathTypes.h"
#include "../include/Rasterizer.h"

int main() {
    // color ARGB
    PixelBuffer* pixelBuffer = new PixelBuffer(0xff0000ff ,800,600);
    ImageWriter* imageWriter = new ImageWriter();
    Rasterizer* rasterizer = new Rasterizer(pixelBuffer);
    VertexProcessor* vp = new VertexProcessor();

    vp->setPerspective(120.0f, 800.0f / 600.0f, 0.1f, 1000.f);
    vp->setLookAt(Float3(0, 0, 0), Float3(0, 0, -1), Float3(0, 1, 0));


    Triangle* t1 = new Triangle(  Float3(-0.5f, 0.5f, 0),
                                           Float3(0.5f, 0.5f, 0),
                                           Float3(0, -0.5f, 0),
                                           Float3(1, 0, 0),
                                           Float3(0, 1, 0),
                                           Float3(0, 0, 1));

    vp->mulByTranslation(Float3(2, 0, 20));
    vp->mulByRotation(90.0f, Float3(0.0f, 0.0f, 1.0f));
    vp->mulByScale(Float3(2, 2, 2));
    t1->v1 = vp->projectVertex(t1->v1).toFloat3();
    t1->v2 = vp->projectVertex(t1->v2).toFloat3();
    t1->v3 = vp->projectVertex(t1->v3).toFloat3();

    std::cout << t1->v1.x << " " << t1->v1.y << " " << t1->v1.z;

    rasterizer->addTriangle(t1);
    rasterizer->fillTriangles();

    imageWriter->saveToFile(pixelBuffer, "test.tga");

    // Clean-up
    delete rasterizer;
    delete t1;
    delete imageWriter;
    delete pixelBuffer;
}
